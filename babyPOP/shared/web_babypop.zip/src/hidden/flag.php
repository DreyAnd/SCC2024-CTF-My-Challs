<?php

$flag = 'SCC{fakeflag}';

?>