<?php

$flag = 'SCC{fakeflag}';

?>
